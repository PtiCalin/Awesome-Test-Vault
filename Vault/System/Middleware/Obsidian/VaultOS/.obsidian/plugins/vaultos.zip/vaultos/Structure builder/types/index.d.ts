/// <reference types="node" />

declare module 'obsidian' {
  export class Plugin {
    app: any;
    addCommand(command: any): void;
  }

  export class Vault {
    createFolder(path: string): Promise<void>;
    getAbstractFileByPath(path: string): any;
    create(path: string, data: string): Promise<void>;
  }

  export class TFolder {}
}
