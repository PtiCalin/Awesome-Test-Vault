// ┌────────────────────────────────────────────┐
// │ 🧠 Dev Typings for Obsidian API (Stub)     │
// └────────────────────────────────────────────┘
// This file is for development only, to avoid TS errors like:
// "Cannot find module 'obsidian' or its corresponding type declarations."
//
// If you are not using the official Obsidian API typings (e.g. via `@types/obsidian`),
// you can stub the required types here manually.
//
// This makes your plugin compile and run without bundling 'obsidian' directly.

// Declare the Obsidian module so imports work in your codebase
declare module 'obsidian' {
  // ───────────────────────────────
  // 🔧 Core Plugin Base Class
  // ───────────────────────────────
  export class Plugin {
    app: App;
    addCommand(options: {
      id: string;
      name: string;
      callback: () => void;
    }): void;
    // Add other lifecycle methods if needed:
    // onload?(): void;
    // onunload?(): void;
  }

  // ───────────────────────────────
  // 🧠 App & Vault Types
  // ───────────────────────────────
  export interface App {
    vault: Vault;
  }

  export class Vault {
    createFolder(path: string): Promise<void>;
    create(path: string, data: string): Promise<void>;
    getAbstractFileByPath(path: string): AbstractFile | null;
  }

  export interface AbstractFile {}

  // ───────────────────────────────
  // 📁 TFolder for folder type hinting
  // ───────────────────────────────
  export interface TFolder extends AbstractFile {
    children: AbstractFile[];
    name: string;
    path: string;
  }
}
